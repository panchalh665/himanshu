package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    EditText e1;
    EditText e2;
    Button b1,b2,b3,b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=(EditText)findViewById(R.id.edittext1);
        e2=(EditText)findViewById(R.id.edittext2);
        b1=(Button)findViewById(R.id.add);
        b2=(Button)findViewById(R.id.sub);
        b3=(Button)findViewById(R.id.mul);
        b4=(Button)findViewById(R.id.div);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a1 = Integer.parseInt(e1.getText().toString());
                int a2 = Integer.parseInt(e2.getText().toString());
                int c1 = a1+a2;
                Toast.makeText(MainActivity.this,"YOUR ADDITION IS=> "+c1,Toast.LENGTH_LONG).show();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a1 = Integer.parseInt(e1.getText().toString());
                int a2 = Integer.parseInt(e2.getText().toString());
                int c1 = a1-a2;
                Toast.makeText(MainActivity.this,"YOUR SUBSTRACTION IS=> "+c1,Toast.LENGTH_LONG).show();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a1 = Integer.parseInt(e1.getText().toString());
                int a2 = Integer.parseInt(e2.getText().toString());
                int c1 = a1*a2;
                Toast.makeText(MainActivity.this,"YOUR MULTIPLICATION IS=> "+c1,Toast.LENGTH_LONG).show();
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a1 = Integer.parseInt(e1.getText().toString());
                int a2 = Integer.parseInt(e2.getText().toString());
                int c1 = a1/a2;
                Toast.makeText(MainActivity.this,"YOUR DIVIDE IS=> "+c1,Toast.LENGTH_LONG).show();
            }
        });
    }
}
